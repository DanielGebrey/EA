package bank.domain;

import java.time.LocalDate;

import jakarta.persistence.*;
import lombok.Data;

@Entity
@Data
public class Tracerecord{
    @Id
    @GeneratedValue
    private int id;
    private LocalDate dateTime;
    private String text;

    public Tracerecord(String text) {
        this.text = text;
        dateTime = LocalDate.now();
    }
}

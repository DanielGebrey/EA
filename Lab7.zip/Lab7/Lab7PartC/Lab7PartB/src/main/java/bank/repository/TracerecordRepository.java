package bank.repository;

import org.springframework.stereotype.Repository;

import bank.domain.Tracerecord;

import org.springframework.data.jpa.repository.JpaRepository;

@Repository
public interface TracerecordRepository extends JpaRepository<Tracerecord, Integer> {
    
}

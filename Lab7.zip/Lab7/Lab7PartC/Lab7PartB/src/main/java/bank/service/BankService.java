package bank.service;

import bank.domain.Account;
import bank.domain.Customer;
import bank.domain.Tracerecord;
import bank.integration.EmailSender;
import bank.repository.AccountRepository;
import bank.repository.CustomerRepository;
import bank.repository.TracerecordRepository;
import jakarta.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class BankService {

	@Autowired
	private AccountRepository accountRepository;

	@Autowired
	private CustomerRepository customerRepository;

	@Autowired
	private EmailSender emailSender;

	@Autowired
	private TracerecordRepository tracerecordRepository;
	
	@Transactional
	public void createCustomerAndAccount(int customerId, String customerName, String emailAddress, String accountNumber){
		 try{
		Account account = new Account(accountNumber);
		accountRepository.save(account);
		Customer customer = new Customer(customerId, customerName);
        customer.setAccount(account);
		customerRepository.saveCustomer(customer);
		emailSender.sendEmail(emailAddress, "Welcome "+customerName);
		 }
	catch(Exception e){
		tracerecordRepository.save(new Tracerecord("Could not create customer"+ customerName +" with account "+accountNumber));
		//emailSender.sendEmail("Could not create customer"+ customerName +" with account "+accountNumber);
			//throw e;
			e.getMessage();

	 }
		 
}
}


